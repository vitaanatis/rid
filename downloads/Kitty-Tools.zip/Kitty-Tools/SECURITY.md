# Security Policy
Only the most **Up to Date** version of this repo will get vulnerability checks!

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| main(most recent)    | :white_check_mark: |


## Reporting a Vulnerability

When you find Vulnerability please make an issue and use the bug issue template, fill out the template and name the title of your issue "vuln by {your username}" 
