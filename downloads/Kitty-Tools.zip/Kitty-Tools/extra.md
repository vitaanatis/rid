<div align="left">

## Website
* {infomation here}

## LITE
* This is a version of Kitty-Tools that is ment to run on slower systems as it doesn't have as many graphical effects so it should be faster, it also doesn't have as many non requires modules so it shouldn't run into any error!

## Definitions
* apt: Advanced Package Tool (High level package installer)
* pkg: Package
* install git: Installs a github Repo via a terminal
* cd: Change directory (Used to go to a file via terminal)
* cmd: Command (You can type "CMD" in the windows start bar to open its command prompt!)
* repo: repository (If your reading this than your looking at a repository's readme.md)
* dir: directory (File location)


## Versions
* You can past versions here:

![Screenshot 2024-01-05 8 21 22 AM](https://github.com/CPScript/Kitty-Tools/assets/83523587/ea8f7306-ee2e-4ca7-8dfb-767df8bfa8cc)

</div>
